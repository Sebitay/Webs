Tarea2:
la parte de hincha no se desarrollo por lo que no se puede ver la informacion de un hincha.

para los artesanos la coneccion a la base de datos se hizo con  user='cc5002', passwd='programacionweb'.

las fotos quedan guardadas en 'static/up'